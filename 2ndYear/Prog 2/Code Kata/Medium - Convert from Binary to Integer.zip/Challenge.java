public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static int fromBinary(String value)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    int x=0;	 	      		  	 	     	     	
    for (int i=0;i<value.length();i++)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      char temp = value.charAt(i);	 	      		  	 	     	     	
      x=2*x;	 	      		  	 	     	     	
      if (temp=='1')	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        x+=1;	 	      		  	 	     	     	
      } else {	 	      		  	 	     	     	
       x +=0;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return x;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}