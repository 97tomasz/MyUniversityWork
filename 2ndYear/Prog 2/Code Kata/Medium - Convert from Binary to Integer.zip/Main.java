public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    System.out.println(Challenge.fromBinary("1111011011")); // 987	 	      		  	 	     	     	
    System.out.println(Challenge.fromBinary("111000")); // 56	 	      		  	 	     	     	
    System.out.println(Challenge.fromBinary("1111111111")); // 1023	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}