public class Building {	 	      		  	 	     	     	
  private int streetNumber;	 	      		  	 	     	     	
  private String streetName;	 	      		  	 	     	     	
  private String postCode;	 	      		  	 	     	     	
  private String ownerName;	 	      		  	 	     	     	
  private Room[] rooms;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public double getTotalFloorSpace(){	 	      		  	 	     	     	
    double x = 0;	 	      		  	 	     	     	
    for (int i=0; i < rooms.length; i++) {	 	      		  	 	     	     	
      double l = rooms[i].getLength();	 	      		  	 	     	     	
      double w = rooms[i].getWidth();	 	      		  	 	     	     	
      double a = l*w;	 	      		  	 	     	     	
      x += a;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return x;	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public void setStreetNumber(int streetNumber)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.streetNumber = streetNumber;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public int getStreetNumber()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.streetNumber;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setStreetName(String streetName)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.streetName = streetName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getStreetName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.streetName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setPostCode(String postCode)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.postCode = postCode;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getPostCode()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.postCode;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setOwnerName(String ownerName)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.ownerName = ownerName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getOwnerName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.ownerName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setRooms(Room[] rooms)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.rooms = rooms;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Room[] getRooms()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.rooms;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}