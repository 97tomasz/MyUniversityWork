public class Room {	 	      		  	 	     	     	
  private int level;	 	      		  	 	     	     	
  private double width;	 	      		  	 	     	     	
  private double length;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setLevel(int level)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.level = level;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public int getLevel()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.level;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setWidth(double width)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.width = width;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public double getWidth()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.width;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setLength(double length)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.length = length;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public double getLength()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.length;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}