public class Main {	 	      		  	 	     	     	
  public static void main(String[] args) {	 	      		  	 	     	     	
	 	      		  	 	     	     	
    Building bob = new Building();	 	      		  	 	     	     	
    Room jeff = new Room();	 	      		  	 	     	     	
    Room ffej = new Room();	 	      		  	 	     	     	
    jeff.setLength(1);	 	      		  	 	     	     	
    jeff.setWidth(1);	 	      		  	 	     	     	
    ffej.setLength(10);	 	      		  	 	     	     	
    ffej.setWidth(10);	 	      		  	 	     	     	
    bob.getTotalFloorSpace();	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}