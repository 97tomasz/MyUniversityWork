public class Address{	 	      		  	 	     	     	
  private int streetNumber;	 	      		  	 	     	     	
  private String cityOrCounty;	 	      		  	 	     	     	
  private String[] addressLines;	 	      		  	 	     	     	
  private String postcode;	 	      		  	 	     	     	
  private String country;	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setStreetNumber(int streetNumber)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.streetNumber = streetNumber;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public int getStreetNumber()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.streetNumber;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setCityOrCounty(String cityOrCounty)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.cityOrCounty = cityOrCounty;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getCityOrCounty()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.cityOrCounty;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setAddressLines(String[] addressLines)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.addressLines = addressLines;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String[] getAddressLines()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.addressLines;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setPostcode(String postcode)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.postcode = postcode;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getPostcode()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.postcode;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setCountry(String country)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.country = country;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getCountry()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.country;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}