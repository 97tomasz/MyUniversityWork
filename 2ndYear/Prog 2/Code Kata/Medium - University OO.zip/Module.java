public class Module{	 	      		  	 	     	     	
  private String name;	 	      		  	 	     	     	
  private String lectureVenue;	 	      		  	 	     	     	
  private String dayOfWeek;	 	      		  	 	     	     	
  private String time;	 	      		  	 	     	     	
  private Lecturer lecturer;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setLecturer(Lecturer lecturer)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.lecturer = lecturer;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Lecturer getLecturer()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.lecturer;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setName(String name)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.name = name;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.name;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setLectureVenue(String lectureVenue)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.lectureVenue = lectureVenue;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getLectureVenue()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.lectureVenue;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setDayOfWeek(String dayOfWeek)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.dayOfWeek = dayOfWeek;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getDayOfWeek()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.dayOfWeek;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setTime(String time)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.time = time;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getTime()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.time;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}