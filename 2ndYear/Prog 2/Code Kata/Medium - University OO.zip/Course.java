public class Course{	 	      		  	 	     	     	
  private String name;	 	      		  	 	     	     	
  private String department;	 	      		  	 	     	     	
  private int durationInYears;	 	      		  	 	     	     	
  private Module[] modules;	 	      		  	 	     	     	
  private Student[] students;	 	      		  	 	     	     	
  private Lecturer lecturer;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setName(String name)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.name = name;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.name;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setDepartment(String department)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.department = department;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getDepartment()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.department;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setDurationInYears(int durationInYears)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.durationInYears = durationInYears;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public int getDurationInYears()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.durationInYears;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setModules(Module[] modules)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.modules = modules;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Module[] getModules()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.modules;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setStudents(Student[] students)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.students = students;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Student[] getStudents()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.students;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setLecturer(Lecturer lecturer)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.lecturer = lecturer;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Lecturer getLecturer()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.lecturer;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}