public class University{	 	      		  	 	     	     	
  private String name;	 	      		  	 	     	     	
  private Address address;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setAddress(Address address)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.address = address;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Address getAddress()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.address;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setName(String name)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.name = name;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.name;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}