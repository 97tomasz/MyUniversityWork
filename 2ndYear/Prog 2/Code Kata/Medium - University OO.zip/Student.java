public class Student extends Person {	 	      		  	 	     	     	
 private String studentNumber;	 	      		  	 	     	     	
  private boolean marketing;	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public void setStudentNumber(String studentNumber)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    this.studentNumber = studentNumber;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public String getStudentNumber()	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    return this.studentNumber;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public void setMarketing(boolean marketing)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    this.marketing = marketing;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public boolean isMarketing()	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    return this.marketing;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}