public class Lecturer extends Person {	 	      		  	 	     	     	
 private String employeeNumber;	 	      		  	 	     	     	
  private String NInumber;	 	      		  	 	     	     	
  private String jobTitle;	 	      		  	 	     	     	
  private double salary;	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public void setEmployeeNumber(String employeeNumber)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    this.employeeNumber = employeeNumber;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public String getEmployeeNumber()	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    return this.employeeNumber;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public void setNInumber(String NInumber)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    this.NInumber = NInumber;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public String getNInumber()	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    return this.NInumber;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public void setJobTitle(String jobTitle)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    this.jobTitle = jobTitle;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public String getJobTitle()	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    return this.jobTitle;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public void setSalary(double salary)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    this.salary = salary;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
 public double getSalary()	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
    return this.salary;	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}