public class Utils	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String[] order(String[] arr)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    for (int x=0;x<arr.length;x++)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
     for (int y=x+1;y<arr.length;y++)	 	      		  	 	     	     	
     {	 	      		  	 	     	     	
      if (arr[x].compareToIgnoreCase(arr[y])>0)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        String temp = arr[x];	 	      		  	 	     	     	
        arr[x]=arr[y];	 	      		  	 	     	     	
        arr[y]=temp;	 	      		  	 	     	     	
     }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
    return arr;	 	      		  	 	     	     	
}	 	      		  	 	     	     	
}