public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    String[] trial1 = Utils.order(new String[]{"apple","ORANGE","plum","banana","fred","ZZZZ","aardvark"});	 	      		  	 	     	     	
    // output should be	 	      		  	 	     	     	
    // aardvark	 	      		  	 	     	     	
    // apple	 	      		  	 	     	     	
    // banana	 	      		  	 	     	     	
    // fred	 	      		  	 	     	     	
    // ORANGE	 	      		  	 	     	     	
    // plum	 	      		  	 	     	     	
    // ZZZZ	 	      		  	 	     	     	
    for (String x : trial1) System.out.println(x);	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}