import java.util.HashSet;	 	      		  	 	     	     	
import java.util.Arrays;	 	      		  	 	     	     	
public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static boolean hasPair(String[] list)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // implement your code here	 	      		  	 	     	     	
    HashSet<String> hash = new HashSet<String>(Arrays.asList(list));	 	      		  	 	     	     	
    boolean temp = true;	 	      		  	 	     	     	
    if (list.length == hash.size())	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      temp = false;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return temp;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}