import java.util.HashMap;	 	      		  	 	     	     	
import java.util.Set;	 	      		  	 	     	     	
import java.util.regex.Matcher;	 	      		  	 	     	     	
import java.util.regex.Pattern;	 	      		  	 	     	     	
import java.util.Iterator;	 	      		  	 	     	     	
	 	      		  	 	     	     	
public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String killDupes(String value)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    value = value.toLowerCase();	 	      		  	 	     	     	
    Pattern p = Pattern.compile("[a-zA-z]+");	 	      		  	 	     	     	
    Matcher m = p.matcher(value);	 	      		  	 	     	     	
    HashMap<String,Integer> tempHM = new HashMap<String,Integer>();	 	      		  	 	     	     	
    String returnString ="";	 	      		  	 	     	     	
    while (m.find())	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      String tempWord=m.group();	 	      		  	 	     	     	
      if (!tempHM.containsKey(tempWord))	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        tempHM.put(tempWord,1);	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    Set<String> tempSet = tempHM.keySet();	 	      		  	 	     	     	
    Iterator<String> itr = tempSet.iterator();	 	      		  	 	     	     	
    while (itr.hasNext())	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
     returnString = returnString+" " + itr.next();	 	      		  	 	     	     	
     returnString=returnString.trim();	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return returnString;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}