public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String killDupes(String value)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    String newString="";	 	      		  	 	     	     	
    value=value.toLowerCase();	 	      		  	 	     	     	
	 	      		  	 	     	     	
    // implement your code here	 	      		  	 	     	     	
	 	      		  	 	     	     	
    for (int i = 0;i<value.length();i++)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      if (newString.indexOf(value.charAt(i))==-1)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        newString=newString+value.charAt(i);	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return newString;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}