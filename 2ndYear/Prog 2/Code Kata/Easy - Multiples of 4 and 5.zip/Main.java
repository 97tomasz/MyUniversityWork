public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args) {	 	      		  	 	     	     	
    int i = 0;	 	      		  	 	     	     	
    for (int count = 1; count <= 1000; count++) {	 	      		  	 	     	     	
      if (count%4 ==0 && count%5 ==0) {	 	      		  	 	     	     	
        i = i + count;	 	      		  	 	     	     	
      } else if (count%4 ==0) {	 	      		  	 	     	     	
        i = i + count;	 	      		  	 	     	     	
      } else if (count%5 ==0) {	 	      		  	 	     	     	
        i = i + count;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
    System.out.println(i);	 	      		  	 	     	     	
	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}