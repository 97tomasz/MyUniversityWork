public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    boolean trial1 = Utils.isPalindrome("poop");	 	      		  	 	     	     	
    System.out.println(trial1); // should be true	 	      		  	 	     	     	
    boolean trial2 = Utils.isPalindrome("aibohphobia");	 	      		  	 	     	     	
    System.out.println(trial2); // is apparently, a fear of palindromes! - should also be true	 	      		  	 	     	     	
    boolean trial3 = Utils.isPalindrome("antidisestablishmentarism");	 	      		  	 	     	     	
    System.out.println(trial3); // should be false;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}