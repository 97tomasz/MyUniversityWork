public class Utils	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static boolean isPalindrome(String target)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // implement your code here	 	      		  	 	     	     	
    // don't forget to return true or false...!	 	      		  	 	     	     	
    String[] x = target.split("(?!^)");	 	      		  	 	     	     	
    String backwards ="";	 	      		  	 	     	     	
    boolean temp = false;	 	      		  	 	     	     	
    for (int i=x.length - 1;i>=0;i--)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
     backwards = backwards +x[i];	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    if (backwards.equals(target))	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      temp = true;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return temp;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}