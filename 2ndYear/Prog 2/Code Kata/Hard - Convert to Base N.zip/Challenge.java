import java.util.Stack;	 	      		  	 	     	     	
public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String convert(int original,int base)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    String total ="";	 	      		  	 	     	     	
    Stack<String> temp = new Stack<String>();	 	      		  	 	     	     	
    int x=0;	 	      		  	 	     	     	
	 	      		  	 	     	     	
    while(original>0)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      switch (original%base)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        case 0:	 	      		  	 	     	     	
          temp.push("0");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 1:	 	      		  	 	     	     	
          temp.push("1");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 2:	 	      		  	 	     	     	
          temp.push("2");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 3:	 	      		  	 	     	     	
          temp.push("3");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 4:	 	      		  	 	     	     	
          temp.push("4");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 5:	 	      		  	 	     	     	
          temp.push("5");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 6:	 	      		  	 	     	     	
          temp.push("6");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 7:	 	      		  	 	     	     	
          temp.push("7");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 8:	 	      		  	 	     	     	
          temp.push("8");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 9:	 	      		  	 	     	     	
          temp.push("9");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 10:	 	      		  	 	     	     	
          temp.push("A");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 11:	 	      		  	 	     	     	
          temp.push("B");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 12:	 	      		  	 	     	     	
          temp.push("C");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 13:	 	      		  	 	     	     	
          temp.push("D");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 14:	 	      		  	 	     	     	
          temp.push("E");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
        case 15:	 	      		  	 	     	     	
          temp.push("F");	 	      		  	 	     	     	
          break;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
      original /= base;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    while(!temp.isEmpty())	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
    total+=temp.pop();	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return total;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }