public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    System.out.println(Challenge.convert(157,2)); // should be 10011101	 	      		  	 	     	     	
    System.out.println(Challenge.convert(300,16)); // should be 12C	 	      		  	 	     	     	
    System.out.println(Challenge.convert(300,8)); // should be 454	 	      		  	 	     	     	
    System.out.println(Challenge.convert(1844,13)); // should be ABB	 	      		  	 	     	     	
    System.out.println(Challenge.convert(16,16)); // should be 10	 	      		  	 	     	     	
    System.out.println(Challenge.convert(8,8)); // should also be 10	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}