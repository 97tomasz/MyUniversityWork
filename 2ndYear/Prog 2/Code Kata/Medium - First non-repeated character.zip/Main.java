public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // should be C	 	      		  	 	     	     	
    System.out.println(Challenge.firstNonRep("AABBC"));	 	      		  	 	     	     	
    // should be D	 	      		  	 	     	     	
    System.out.println(Challenge.firstNonRep("AABBCCDEEFF"));	 	      		  	 	     	     	
    // should be A	 	      		  	 	     	     	
    System.out.println(Challenge.firstNonRep("ABBCCDEEFF"));	 	      		  	 	     	     	
    // should be X	 	      		  	 	     	     	
    System.out.println(Challenge.firstNonRep("AABBCCDDEEFF"));	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}