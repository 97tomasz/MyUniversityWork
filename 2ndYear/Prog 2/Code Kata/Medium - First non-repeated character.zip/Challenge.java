public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static char firstNonRep(String str)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    if (str.length() ==1){	 	      		  	 	     	     	
      return str.charAt(0);	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
    int count =1;	 	      		  	 	     	     	
    for (int x = 0; x<str.length()-1;x++) {	 	      		  	 	     	     	
      if (str.charAt(x) == str.charAt(x+1)){	 	      		  	 	     	     	
        count++;	 	      		  	 	     	     	
      }else{	 	      		  	 	     	     	
        if (count ==1){	 	      		  	 	     	     	
          return str.charAt(x);	 	      		  	 	     	     	
        }else{	 	      		  	 	     	     	
          count =1;	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    if (count ==1){	 	      		  	 	     	     	
      return str.charAt(str.length()-1);	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return 'X';	 	      		  	 	     	     	
}	 	      		  	 	     	     	
}