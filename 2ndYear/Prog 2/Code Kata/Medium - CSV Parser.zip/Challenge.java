import java.util.*;	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String[] csvParse(String data)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // implement your code here	 	      		  	 	     	     	
    List<String> tempList = new ArrayList<String>();	 	      		  	 	     	     	
    StringBuilder build = new StringBuilder();	 	      		  	 	     	     	
    for (int x=0;x<data.length();x++)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
     if (data.charAt(x) !=',')	 	      		  	 	     	     	
     {	 	      		  	 	     	     	
       build.append(data.charAt(x));	 	      		  	 	     	     	
     }else{	 	      		  	 	     	     	
       tempList.add(build.toString());	 	      		  	 	     	     	
       build = new StringBuilder();	 	      		  	 	     	     	
     }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    tempList.add(build.toString());	 	      		  	 	     	     	
    return tempList.toArray(new String[]{});	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}