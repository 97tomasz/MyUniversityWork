public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // should end up with an array containing {"this","is","a","test"}	 	      		  	 	     	     	
    String[] results = Challenge.csvParse("this,is,a,test");	 	      		  	 	     	     	
    for (String result : results)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      System.out.println(result);	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    // will print out, on separate lines	 	      		  	 	     	     	
    // this	 	      		  	 	     	     	
    // is	 	      		  	 	     	     	
    // a	 	      		  	 	     	     	
    // test	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}