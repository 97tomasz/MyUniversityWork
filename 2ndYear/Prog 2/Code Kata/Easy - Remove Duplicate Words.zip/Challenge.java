import java.util.ArrayList;	 	      		  	 	     	     	
public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String killDupes(String value)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    String word[] = value.split(" ");	 	      		  	 	     	     	
    ArrayList<String> SortWord = new ArrayList<String>();	 	      		  	 	     	     	
    String nonDupeWord ="";	 	      		  	 	     	     	
    for (String w : word)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
     if (!SortWord.contains(w.toLowerCase()))	 	      		  	 	     	     	
     {	 	      		  	 	     	     	
      SortWord.add(w.toLowerCase());	 	      		  	 	     	     	
     }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    for (String temp : SortWord)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
     nonDupeWord += temp + " ";	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return nonDupeWord.trim();	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}