public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     System.out.println(Challenge.killDupes("Spam spam spam egg chips and spam"));	 	      		  	 	     	     	
     // should print Spam egg chips and	 	      		  	 	     	     	
	 	      		  	 	     	     	
     System.out.println("This is not good and not bad");	 	      		  	 	     	     	
     // should print This is not good and bad	 	      		  	 	     	     	
	 	      		  	 	     	     	
     System.out.println("Badger badger badger badger");	 	      		  	 	     	     	
     // should print Badger	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}