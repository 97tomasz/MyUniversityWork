public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static int multiply(int a, int b)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
   int solved = 0;	 	      		  	 	     	     	
     for(int count=0; count < a; count++){	 	      		  	 	     	     	
       solved = solved + b;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return solved;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}