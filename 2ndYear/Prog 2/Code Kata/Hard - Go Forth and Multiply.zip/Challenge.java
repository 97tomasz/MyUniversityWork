public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static int multiply(int x, int y)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    if (x<y)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      return multiply(y,x);	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    else if (y!=0)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      return (x+multiply(x,y-1));	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    else	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
    return 0;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}