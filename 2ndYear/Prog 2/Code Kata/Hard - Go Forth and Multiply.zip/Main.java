public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    System.out.println(Challenge.multiply(10,3)); // 30	 	      		  	 	     	     	
    System.out.println(Challenge.multiply(6,2)); // 12	 	      		  	 	     	     	
    System.out.println(Challenge.multiply(9,3)); // 27	 	      		  	 	     	     	
    System.out.println(Challenge.multiply(6,6)); // 36	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}