public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static String reverseWords(String original)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // implement your code here	 	      		  	 	     	     	
    String[] arrayWord=original.split(" ");	 	      		  	 	     	     	
    String backwards="";	 	      		  	 	     	     	
    for(int i=0;i<arrayWord.length;i++)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      String strWord=arrayWord[i];	 	      		  	 	     	     	
      String backwardWord =""; //or backWord (see what I did there)	 	      		  	 	     	     	
      for (int j =strWord.length()-1; j>=0;j--)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
       backwardWord=backwardWord+strWord.charAt(j);	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
      backwards=backwards+backwardWord+" ";	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return backwards.trim();	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}