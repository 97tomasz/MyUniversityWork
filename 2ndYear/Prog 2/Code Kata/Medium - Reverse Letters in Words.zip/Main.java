public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    String original = "Reverse the words in this sentence";	 	      		  	 	     	     	
    System.out.println(Challenge.reverseWords(original)); // should be "sesreveR eht sdrow ni siht ecnetnes"	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}