public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    int[] firstTest = {3,4,5,6,7};	 	      		  	 	     	     	
    Challenge.pairSum(firstTest,10); // should print out 4,6 and 3,7	 	      		  	 	     	     	
    int[] secondTest = {7,8,9,10,11,12};	 	      		  	 	     	     	
    Challenge.pairSum(secondTest,18); // should print out 8,10 and 7,11	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}