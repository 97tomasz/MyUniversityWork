public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void pairSum(int arr[], int value)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    for (int x=0; x<arr.length;x++){	 	      		  	 	     	     	
      for (int y=x+1;y<arr.length;y++){	 	      		  	 	     	     	
        if(arr[x]+arr[y]==value){	 	      		  	 	     	     	
          System.out.println(arr[x]+","+arr[y]);	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}