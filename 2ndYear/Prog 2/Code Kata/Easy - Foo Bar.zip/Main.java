public class Main {	 	      		  	 	     	     	
  public static void main(String[] args) {	 	      		  	 	     	     	
    for (int count = 1; count < 101; count = count + 1) {	 	      		  	 	     	     	
	 	      		  	 	     	     	
      System.out.println(FooBarCheck.FB(count));	 	      		  	 	     	     	
	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
}