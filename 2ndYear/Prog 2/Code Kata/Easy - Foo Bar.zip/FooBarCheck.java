public class FooBarCheck {	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public static String FB(int a){	 	      		  	 	     	     	
    String output = "";	 	      		  	 	     	     	
    int mod3 = a%3;	 	      		  	 	     	     	
    int mod5 = a%5;	 	      		  	 	     	     	
    if ((mod3 ==0) && (mod5==0)) {	 	      		  	 	     	     	
      output = "FooBar";	 	      		  	 	     	     	
    }else if (mod5 == 0) {	 	      		  	 	     	     	
      output = "Foo";	 	      		  	 	     	     	
	 	      		  	 	     	     	
    } else if (mod3 == 0) {	 	      		  	 	     	     	
      output = "Bar";	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    else {	 	      		  	 	     	     	
      output = Integer.toString(a);	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
  return output;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}