public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static int sumPlusOne(int[] numbers)	 	      		  	 	     	     	
{	 	      		  	 	     	     	
    int count = 0;	 	      		  	 	     	     	
    int result = 0;	 	      		  	 	     	     	
    for (count=0; count < numbers.length;count++) {	 	      		  	 	     	     	
      result = result + numbers[count];	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    result = result + count;	 	      		  	 	     	     	
    return result;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}