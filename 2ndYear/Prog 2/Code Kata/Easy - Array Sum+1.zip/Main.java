public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    int[] first = {1,2,3,4,5};	 	      		  	 	     	     	
    System.out.println(Challenge.sumPlusOne(first)); // should be 20	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}