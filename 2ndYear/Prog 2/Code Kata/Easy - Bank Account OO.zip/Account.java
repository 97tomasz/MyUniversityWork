public class Account {	 	      		  	 	     	     	
 public Account(){	 	      		  	 	     	     	
   this.setBalance(10.00);	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
  private double balance;	 	      		  	 	     	     	
  public void setBalance(double balance)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
   this.balance = balance;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public double getBalance()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
   return this.balance;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public void deposit(double deposit)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
   this.setBalance(this.getBalance()+deposit);	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public void withdraw(double withdraw)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
   if (this.getBalance() - withdraw < 0)	 	      		  	 	     	     	
   {	 	      		  	 	     	     	
    System.out.println("ERROR - Insufficient funds");	 	      		  	 	     	     	
   } else {	 	      		  	 	     	     	
     this.setBalance(this.getBalance() - withdraw);	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}	 	      		  	 	     	     	
}