public class Main{	 	      		  	 	     	     	
 public static void main (String[] args)	 	      		  	 	     	     	
 {	 	      		  	 	     	     	
   Account test = new Account();	 	      		  	 	     	     	
   test.deposit(2000.00);	 	      		  	 	     	     	
   System.out.println(test.getBalance());	 	      		  	 	     	     	
	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}