public class Challenge	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void scan(String text)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    text=text.toLowerCase();	 	      		  	 	     	     	
    int temp = 0;	 	      		  	 	     	     	
    String top="";	 	      		  	 	     	     	
    String mid="";	 	      		  	 	     	     	
    String bot="";	 	      		  	 	     	     	
	 	      		  	 	     	     	
    for(int i=0;i<text.length();i++) {	 	      		  	 	     	     	
      if (text.charAt(i) =='b' ||  text.charAt(i) =='d' || text.charAt(i) =='f' || text.charAt(i) =='h' || text.charAt(i) =='k' || text.charAt(i) =='l' || text.charAt(i) =='t')	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        temp = 1;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
      else if (text.charAt(i) =='g' || text.charAt(i) =='j' || text.charAt(i) =='p' || text.charAt(i) =='q' || text.charAt(i) =='y')	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
       temp = 2;	 	      		  	 	     	     	
      }else if (text.charAt(i)==' '){	 	      		  	 	     	     	
       temp = 4;	 	      		  	 	     	     	
      } else {	 	      		  	 	     	     	
       temp = 3;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
	 	      		  	 	     	     	
    switch (temp) {	 	      		  	 	     	     	
      case 1:	 	      		  	 	     	     	
        top = top+"|";	 	      		  	 	     	     	
        mid = mid+"|";	 	      		  	 	     	     	
        bot = bot+" ";	 	      		  	 	     	     	
        break;	 	      		  	 	     	     	
      case 2:	 	      		  	 	     	     	
        top = top+" ";	 	      		  	 	     	     	
        mid = mid+"|";	 	      		  	 	     	     	
        bot = bot+"|";	 	      		  	 	     	     	
        break;	 	      		  	 	     	     	
      case 3:	 	      		  	 	     	     	
        top = top+" ";	 	      		  	 	     	     	
        mid = mid+"|";	 	      		  	 	     	     	
        bot = bot+" ";	 	      		  	 	     	     	
        break;	 	      		  	 	     	     	
      case 4:	 	      		  	 	     	     	
        top = top+" ";	 	      		  	 	     	     	
        mid = mid+" ";	 	      		  	 	     	     	
        bot = bot+" ";	 	      		  	 	     	     	
      case 0:	 	      		  	 	     	     	
        break;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    System.out.println(top);	 	      		  	 	     	     	
    System.out.println(mid);	 	      		  	 	     	     	
    System.out.println(bot);	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}