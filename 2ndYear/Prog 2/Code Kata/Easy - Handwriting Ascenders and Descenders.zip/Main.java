public class Main	 	      		  	 	     	     	
{	 	      		  	 	     	     	
  public static void main(String[] args)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    // note that we can't include pipe characters in example code.	 	      		  	 	     	     	
    // We're using exclamation marks instead in the examples	 	      		  	 	     	     	
    // shown below:	 	      		  	 	     	     	
	 	      		  	 	     	     	
        Challenge.scan("hello paul");	 	      		  	 	     	     	
	 	      		  	 	     	     	
    //                  ! !!     !	 	      		  	 	     	     	
    //                  !!!!! !!!!	 	      		  	 	     	     	
    //                        !	 	      		  	 	     	     	
        Challenge.scan("hucking fell");	 	      		  	 	     	     	
    //                  !  !    ! !!	 	      		  	 	     	     	
    //                  !!!!!!! !!!!	 	      		  	 	     	     	
    //                        !	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}