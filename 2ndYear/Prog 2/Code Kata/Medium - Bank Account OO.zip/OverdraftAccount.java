public class OverdraftAccount extends Account	 	      		  	 	     	     	
                                                  {	 	      		  	 	     	     	
public OverdraftAccount(double overdraft)	 	      		  	 	     	     	
                                                  {	 	      		  	 	     	     	
setOverdraft(0-overdraft);	 	      		  	 	     	     	
                                                  }	 	      		  	 	     	     	
private double overdraft;	 	      		  	 	     	     	
public void setOverdraft(double overdraft)	 	      		  	 	     	     	
                                                  {	 	      		  	 	     	     	
this.overdraft = overdraft;	 	      		  	 	     	     	
                                                  }	 	      		  	 	     	     	
public double getOverdraft()	 	      		  	 	     	     	
                                                  {	 	      		  	 	     	     	
return this.overdraft;	 	      		  	 	     	     	
                                                  }	 	      		  	 	     	     	
public void withdraw(double withdraw)	 	      		  	 	     	     	
                                                  {	 	      		  	 	     	     	
if (this.getBalance() - withdraw > this.getOverdraft())	 	      		  	 	     	     	
                                                  {	 	      		  	 	     	     	
this.setBalance(this.getBalance() - withdraw);	 	      		  	 	     	     	
                                                  }	 	      		  	 	     	     	
else                                              {	 	      		  	 	     	     	
System.out.println("ERROR - Insufficient Funds");	 	      		  	 	     	     	
                                                  }}}	 	      		  	 	     	     	
//I hope I made your eyes bleed with these indentations