public class Citizen {	 	      		  	 	     	     	
	 	      		  	 	     	     	
  private String givenName;	 	      		  	 	     	     	
  private String familyName;	 	      		  	 	     	     	
  private int age;	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setGivenName(String givenName)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.givenName = givenName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getGivenName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.givenName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setFamilyName(String familyName)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.familyName = familyName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getFamilyName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.familyName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setAge(int age)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    if (age < 0) {	 	      		  	 	     	     	
      this.age = 18;	 	      		  	 	     	     	
    } else {	 	      		  	 	     	     	
     this.age = age;	 	      		  	 	     	     	
	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public int getAge()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.age;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Citizen(String name, String family, int sAge) {	 	      		  	 	     	     	
    givenName = name;	 	      		  	 	     	     	
    familyName = family;	 	      		  	 	     	     	
    if (sAge < 0) {	 	      		  	 	     	     	
      age = 18;	 	      		  	 	     	     	
    } else {	 	      		  	 	     	     	
    age = sAge;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public String getFullName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.givenName + " " + this.familyName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public int getTaxableYears()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    int taxYears;	 	      		  	 	     	     	
    if (this.age < 18) {	 	      		  	 	     	     	
      taxYears =0;	 	      		  	 	     	     	
    } else {	 	      		  	 	     	     	
    taxYears = this.age - 18;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
    return taxYears;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}