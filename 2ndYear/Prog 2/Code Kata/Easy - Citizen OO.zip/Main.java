public class Main {	 	      		  	 	     	     	
 public static void main (String[] args){	 	      		  	 	     	     	
	 	      		  	 	     	     	
   Citizen test = new Citizen("Bob", "Ross", 22);	 	      		  	 	     	     	
   Citizen test2 = new Citizen("Jimmy", "Saville", -3);	 	      		  	 	     	     	
	 	      		  	 	     	     	
   System.out.println(test.getAge());	 	      		  	 	     	     	
   System.out.println(test.getFullName());	 	      		  	 	     	     	
   System.out.println(test.getTaxableYears());	 	      		  	 	     	     	
   System.out.println(test2.getAge());	 	      		  	 	     	     	
   System.out.println(test2.getFullName());	 	      		  	 	     	     	
   System.out.println(test2.getTaxableYears());	 	      		  	 	     	     	
 }	 	      		  	 	     	     	
}