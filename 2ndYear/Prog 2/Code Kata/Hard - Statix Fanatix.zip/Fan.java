public class Fan {	 	      		  	 	     	     	
  private String givenName;	 	      		  	 	     	     	
  private String familyName;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setGivenName(String givenName)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.givenName = givenName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getGivenName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.givenName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setFamilyName(String familyName)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     this.familyName = familyName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String getFamilyName()	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
     return this.familyName;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
  private int day;	 	      		  	 	     	     	
  private int month;	 	      		  	 	     	     	
  private int year;	 	      		  	 	     	     	
  private static int count;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public Fan(){	 	      		  	 	     	     	
   this.count++;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public void setDate(int day, int month, int year) {	 	      		  	 	     	     	
    this.day = day;	 	      		  	 	     	     	
    this.month = month;	 	      		  	 	     	     	
    this.year = year;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public String getDate(){	 	      		  	 	     	     	
    return (this.day +"/"+ this.month+"/"+this.year);	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
  public double getRate(){	 	      		  	 	     	     	
    if (this.count < 101) {	 	      		  	 	     	     	
      return 0.5;	 	      		  	 	     	     	
    } else {	 	      		  	 	     	     	
      return 1;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}