<?php
class Admin
{
    private $id;
    private $Username;
    private $Password;
    private $Priviledges;
    function __get($admin) {
        return $this->$booking;
    }

    function __set($admin, $value) {
        return $this->$admin = $value;
    }

}


?>