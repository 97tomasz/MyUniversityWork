<?php
class Vehicle_Model{
    private $ModelID;
    private $VehicleModel;
    private $NumberOfVehicles;
    private $Passengers;
    private $DrivingLicense;
    private $HourlyRate;

    function __get($vehicle_Model) {
        return $this->$vehicle_Model;
    }

    function __set($vehicle_Model, $value) {
        return $this->$vehicle_Model = $value;
    }
}



?>
