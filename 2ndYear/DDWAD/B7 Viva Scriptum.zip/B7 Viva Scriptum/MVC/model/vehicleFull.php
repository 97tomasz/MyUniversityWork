<?php
class vehicleFull {
    private $VehicleID;
    private $ModelID;
    private $VehicleModel;
    private $NumberOfVehicles;
    private $Passengers;
    private $DrivingLicense;
    private $HourlyRate;

    function __get($vehicle) {
        return $this->$vehicle;
    }

    function __set($vehicle, $value) {
        return $this->$vehicle = $value;
    }


}