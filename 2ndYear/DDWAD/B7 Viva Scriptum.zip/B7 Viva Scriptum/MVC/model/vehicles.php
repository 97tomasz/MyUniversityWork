<?php
class Vehicles {
    private $VehicleID;
    private $ModelID;

    function __get($vehicles) {
        return $this->$vehicle;
    }

    function __set($vehicles, $value) {
        return $this->$vehicle = $value;
    }
}