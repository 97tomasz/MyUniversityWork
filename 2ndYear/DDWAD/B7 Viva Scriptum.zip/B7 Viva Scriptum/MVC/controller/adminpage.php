<?php

require_once "../model/vehicles.php";
require_once "../model/dbaccess.php";


if(isset($_REQUEST["delete"])){

    $vehicleID = $_REQUEST["delete"];
    deleteVehicleByID($vehicleID);
    
    
}

if(!isset($_REQUEST["destination"]))
{
  $results = getVehicleFull();
}

else
{
  $VehicleID = $_REQUEST["VehicleID"];
  $ModelID = $_REQUEST["ModelID"];


    $vehicle = new Vehicles();
    $vehicle->vehicleID = htmlentities($VehicleID);
    $vehicle->modelID = htmlentities($ModelID);




    addNewVehicle($vehicle);


    $results = getVehicleFull();
}
if(isset($_REQUEST["editButton"])){
    $VehicleChosen = $_REQUEST["VehicleChosen"];
    $editVehicleID = $_REQUEST["editVehicleID"];
    $editModelID = $_REQUEST["editModelID"];
    $editVehicleModel = $_REQUEST["editVehicleModel"];
    $editNumberOfVehicle = $_REQUEST["editNumberOfVehicle"];
    $editPassengers = $_REQUEST["editPassengers"];
    $editDrivingLicense = $_REQUEST["editDrivingLicense"];
    $editHourlyRate = $_REQUEST["editHourlyRate"];
 
    editVehicle($VehicleChosen, $editVehicleID, $editModelID, $editVehicleModel, $editNumberOfVehicle, $editPassengers, $editDrivingLicense, $editHourlyRate);
    
    

    
    $results = getVehicleFull();
        }
    
    
    
      require_once "../view/adminpage_view.php"
    
    
    ?>