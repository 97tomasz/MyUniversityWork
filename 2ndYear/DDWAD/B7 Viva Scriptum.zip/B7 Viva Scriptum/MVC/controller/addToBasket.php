<?php 
if (!isset($_SESSION["basket"]))
{
    $basket=[];
    $_SESSION["basket"]=$basket;

} else {
    $basket = $_SESSION["basket"];

}

if (isset($_REQUEST["VehicleID"])){

    $inputID = $_REQUEST["VehicleID"];
    array_push($basket, $_SESSION["basket"],$inputID);
    $_SESSION["basket"] = array_unique($basket,SORT_REGULAR);

}


header('Location: ../view/basket.php');


?>