<?php
require_once "../model/dbaccess.php"; 
if (session_status() == PHP_SESSION_NONE)
{
session_start();
}
$tempBus = getVehicleFull();

if (!isset ($_SESSION["basket"]))
{
    $temp = [];

} else {
    $temp = $_SESSION["basket"];
}

$vehCheck = [];


foreach($temp as $basketID){
    foreach($tempBus as $check)
    {
        if($check->$vehicleID == $basketID)
        {
            $vehCheck[]=$check;

        }
    }
}
?>
