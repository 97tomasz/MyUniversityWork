<?php 
$_SESSION["loggedIn"]=0;

?>
