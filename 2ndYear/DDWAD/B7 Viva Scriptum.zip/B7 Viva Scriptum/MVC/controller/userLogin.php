<?php
session_start();
require_once "../model/user.php";
require_once "../model/dbaccess.php";





$correctDetails = false;
$_SESSION['userLoggedInMessage'] = "";
if(isset($_REQUEST['username'])){
$username = $_REQUEST['username'];
$password = $_REQUEST['password'];
$results = getAllAdmins();

foreach($results as $user){
if(($user->username == $username) && ($user->password == $password)){
$correctDetails = true;
$username = $user->username;
}

}

if($correctDetails == true){
$_SESSION['username'] = $username;
$_SESSION['password'] =$password;
$_SESSION['userLoggedInMessage'] = "Succesfully logged in";
} else {
$_SESSION['userLoggedInMessage'] = "Wrong log-in details or user doesn't exist";

}
}


require_once "../view/userLogin_view.php";

 ?>
