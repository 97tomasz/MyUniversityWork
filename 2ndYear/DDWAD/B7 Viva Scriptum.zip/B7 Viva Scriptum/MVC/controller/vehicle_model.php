<?php
require_once "../model/vehicle_Model.php";
require_once "../model/dbaccess.php";
$Vehicle_ModelResults = getAllVehicle_Model();
?>