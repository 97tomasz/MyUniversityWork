<?php
if (session_status() == PHP_SESSION_NONE)
    {
    session_start();
    }
if(!isset($_SESSION["loggedIn"]))
    {
    $_SESSION["loggedIn"]=0;
    }
require_once "../model/dbaccess.php";

if(isset($_REQUEST["Password"]))
{
    $Username = $_REQUEST["Username"];
    $Password = $_REQUEST["Password"];
    $usernameResults = GetAdminUsername();
    $passwordResults = GetAdminPassword();
    foreach ($usernameResults as $admin) 
    {
        if ($Username == $usernameResults) 
        {
            if ($Password == $passwordResults) 
            {
                $_SESSION["loggedIn"]=1;
            }   
        }
    }
}
if($_SESSION["loggedIn"]=1)
{
 header("Location: ../view/adminpage.php");
}


?>