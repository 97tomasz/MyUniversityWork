<?php
require_once "../model/vehicles.php";
require_once "../model/dbaccess.php";

$VehicleResults = getVehicleFull();
?>