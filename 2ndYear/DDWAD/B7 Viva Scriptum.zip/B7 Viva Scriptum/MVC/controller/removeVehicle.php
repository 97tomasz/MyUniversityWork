<?php
require_once "vehiclebookingservice/model/vehicles.php";
require_once "vehiclebookingservice/model/dbaccess.php";

$results = removeVehicle();

echo $results;