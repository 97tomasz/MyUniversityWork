<?php
require_once "vehiclebookingservice/model/vehicles.php";
require_once "vehiclebookingservice/model/dbaccess.php";

if (isset($_REQUEST["newVehicle"]) && isset($_REQUEST["newModel"])) {
    $x = $_REQUEST["newVehicle"];
    $y = $_REQUEST["newModel"];

    $results = addNewVehicle($x, $y);
    echo $results;
}


