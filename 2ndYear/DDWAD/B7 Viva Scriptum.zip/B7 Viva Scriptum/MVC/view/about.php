<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" type="text/css" href="every.css">
</head>
<body>

    <img src="bus-banner.jpg" width="100%">
        <div class="topnav">
            <a href="index.php">Home</a>
            <a href="vehicle.php">Vehicles</a>
            <a href="booking.php">Booking</a>
            <a href="basket.php">Basket</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="register.php">Register</a>
            <a href="userLogin.php">Login</a>
        </div>
<br>
    <p1> We are a family owned business </p1> <br>
    <p2> paragraph 2 </p2><br>
    <a href ="https://gitlab.kingston.ac.uk/K1602155/DDWAD.git">B7 Gitlab page </a>
    <div class="footer">
        <p>Berwyn Bus Hire Company Ltd</p>
        <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
    </div>

</body>
<footer>

</footer>