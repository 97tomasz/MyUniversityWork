<?php 
require_once "../controller/basket.php"; ?>
<html>
<head>
    <title>Shopping Cart</title>
    
    <link rel="stylesheet" type="text/css" href="every.css">

</head>
<body>
        <img src="bus-banner.jpg" width=100%><br>
        <div class="topnav">
            <a href="index.php">Home</a>
            <a href="vehicle.php">Vehicles</a>
            <a href="booking.php">Booking</a>
            <a href="basket.php">Basket</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="register.php">Register</a>
            <a href="userLogin.php">Login</a>
        </div>
        <div class="col-25">
            <table>
                <thead>
                <tr>
                    <th>Vehicle ID</th>
                    <th>Model ID</th>
                    <th>Model Name</th>
                    <th>Number Of Vehicles</th>
                    <th>Passenger Limit</th>
                    <th>Driving License Required</th>
                    <th>Hourly Rate in £ </th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($vehCheck as $vehicle):?>
                <td><? $vehicle->vehicleID?></td>
                <?php endforeach ?>
                </tbody>
            </table>
              </div>
            </div>
        
            <div class="footer">
                        <p>Berwyn Bus Hire Company Ltd</p>
                        <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
            </div>

    </form>
</body>
</html>