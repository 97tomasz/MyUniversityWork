<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="every.css">
    <h1>Booking</h1>
    <body>
        <img src="bus-banner.jpg" width=100%><br>
        <div class="topnav">
                <a href="index.php">Home</a>
                <a href="vehicle.php">Vehicles</a>
                <a href="booking.php">Booking</a>
                <a href="basket.php">Basket</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
                <a href = "register.php">Register</a>
            <a href = "loginpage.php">/ Login</a>
        </div>
    <form action="booking.php">
        Pickup Location
        <input type="text" name="Pickup"><br>
        Pickup Date
        <input type="text" name="Date">Pickup Time <input type="text" name="Time"><br>
        Return Location
        <input type="text" name="return"><br>
        Return Date
        <input type="text" name="RDate">Return Time <input type="text" name="RTime"><br>
        <br>
        <submit>Next</a>
    
        <div class="footer">
            <p>Berwyn Bus Hire Company Ltd</p>
            <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
        </div>

    </form>
    
</body>    
</html>