<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Welcome to Berwyn Buses - Home</title>
        <link rel="stylesheet" type="text/css" href="every.css">
        
    </head>
    <body>

        <img src="bus-banner.jpg" width=100%>
        <div class="topnav">
            <a href="index.php">Home</a>
            <a href="vehicle.php">Vehicles</a>
            <a href="booking.php">Booking</a>
            <a href="basket.php">Basket</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="register.php">Register</a>
            <a href="userLogin.php">Login</a>
        </div>
            <div class="search-container">
                <form action="/action_page.php">
                  <input type="text" placeholder="Search.." name="search">
                  <button type="submit">Submit</button>
                </form>
              </div>
        </div><br><br><br>
        <h1> Welcome to Berwyn Buses! Please use the navbar to navigate to your choice of page </h1>         
            <div class="footer">
                    <p>Berwyn Bus Hire Company Ltd</p>
                    <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
            </div>
        <br><br>
        <
        
</body>
</html>