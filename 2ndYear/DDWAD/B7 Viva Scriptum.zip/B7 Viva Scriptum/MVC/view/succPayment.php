<html>
<head>
    <title>Payment Sucessful</title>
    
    <link rel="stylesheet" type="text/css" href="every.css">
    
</head>
<body>
    <img src="bus-banner.jpg" width=100%>

	
    <div class="topnav">
            <a href="index.php">Home</a>
            <a href="vehicle.php">Vehicles</a>
            <a href="booking.php">Booking</a>
            <a href="basket.php">Basket</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="register.php">Register</a>
            <a href="userLogin.php">Login</a>
        </div>

    <br><br><br>
    
        <h1>Your payment is succesful.</h1>
        <p>Thank you for your order.</p>
        <p>Please check your email for the order confirmation and order number.</p>
        <p>Having trouble..<a href="contact.php">Contact Us</a></p>
        <input type="button">Click to Home Page</button>
        
        <div class="footer">
                <p>Berwyn Bus Hire Company Ltd</p>
                <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
        </div>
    </form>
</body>    
</html>