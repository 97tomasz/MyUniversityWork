<html>
<head>
    <title>Register Page</title>
    <link rel="stylesheet" type="text/css" href="every.css">
</head>
<body>
    <img src="bus-banner.jpg" width=100%>
    <div class="topnav">
            <a href="search.php">Home</a>
            <a href="vehicle.php">Vehicles</a>
            <a href="booking.php">Booking</a>
            <a href="basket.php">Basket</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href = "register.php">Register</a>
            <a href = "loginpage.php">/ Login</a>
        </div>
<?php if(isset($_SESSION["userAddedMessage"])): ?>
<p><font color="red"> <?= $_SESSION["userAddedMessage"] ?> </font></p>
<?php endif ?>



  <form ID="userAdd" method="post" action ="userSignup_controller.php">
    ID: <br>
    <input type="text" name="username" required><br>
    username: <br>
    <input type="text" name="username" required><br>

    Enter Password: <br>
    <input type="password" name="pass1"required><br>
    Re-enter Password: <br>
    <input type="password" name="pass2"required><br>
  <input type="submit" value="Sign-up">

        <div class="container signin">
            <p>Already have an account?<a href="userLogin_view.php">Sign In</a></p>
        </div>

        <div class="footer">
                <p>Berwyn Bus Hire Company Ltd</p>
                <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
        </div>

    </form>
</body>    
</html>