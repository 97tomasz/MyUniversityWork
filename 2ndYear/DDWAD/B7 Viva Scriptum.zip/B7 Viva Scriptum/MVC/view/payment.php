<html>
<head>
    <title>Payment</title>
    <link rel="stylesheet" type="text/css" href="every.css">
</head>
<body>
    <img src="bus-banner.jpg" width=100%><br>
    <div class="topnav">
            <a href="index.php">Home</a>
            <a href="vehicle.php">Vehicles</a>
            <a href="booking.php">Booking</a>
            <a href="basket.php">Basket</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="register.php">Register</a>
            <a href="userLogin.php">Login</a>
        </div>
    <br>
    <img src="https://transcriptdivas.com/wp-content/uploads/2017/05/Paypal.png"  class="center" width=400 height=100><br><br><br>
    <form>
        <label for="carttype">Type</label>
        <select id="ct" name="card">
          <option value="master">MasterCard</option>
          <option value="visa">VisaCard</option>
          <option value="americanexpress">American Express</option>
          <option value="credit">Credit Card</option>
        </select><br><br>
        Cardholder's Name 
        <input type="text" name="Cardholder">
	    Card Number
        <input type="text" name="cardnumber"><br>
        Valid Date
        <input type="text" name="Valid">CVV/CVC* <input type="text" name="CVV"><br>
    <h3>Billing Information</h3>
        Company name
        <input type="text" name="Company name"><br>
        Name
        <input type="text" name="name"><br>
        Address
        <input type="text" name="Address"><br>
        City
        <input type="text" name="City"><br>
        Postcode
        <input type="text" name="Postcode">Phone Number<input type="text" name="Phone"><br>
        Email
        <input type="text" name="Email"><br>
        <a href="bookingvehicle.html">Back</a><br><br><br>
        <a href="successfulpayment.html" target="_blank">Pay</a>
        <div class="footer">
            <p>Berwyn Bus Hire Company Ltd</p>
            <p>K1602155 / K1834977 / K1524638 / K1823571 / K1515883 / K1709948</p>
        </div>
    </form>
</body>
</html>