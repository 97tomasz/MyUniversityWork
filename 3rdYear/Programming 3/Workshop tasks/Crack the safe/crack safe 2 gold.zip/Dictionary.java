import java.util.List;	 	      		  	 	     	     	
	 	      		  	 	     	     	
 // Do not modify this code it is to check your solution with a sample Dictionary of words	 	      		  	 	     	     	
	 	      		  	 	     	     	
public interface Dictionary {	 	      		  	 	     	     	
    List<String> getListOfWords();	 	      		  	 	     	     	
}