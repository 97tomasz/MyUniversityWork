import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.Arrays;	 	      		  	 	     	     	
import java.util.Collections;	 	      		  	 	     	     	
import java.util.List;	 	      		  	 	     	     	
import java.util.Random;	 	      		  	 	     	     	
	 	      		  	 	     	     	
/**	 	      		  	 	     	     	
 *	 	      		  	 	     	     	
 * @author ku14009	 	      		  	 	     	     	
 */	 	      		  	 	     	     	
public class Task2GoldPassword implements Password{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public String generatePassword() {	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
            // Sample Task2Gold Passwords based on List of 10 common English words for student code testing	 	      		  	 	     	     	
            words.add("drowssap");	 	      		  	 	     	     	
            words.add("ytrewq");	 	      		  	 	     	     	
            words.add("dtunam");	 	      		  	 	     	     	
            words.add("aeslehc");	 	      		  	 	     	     	
            words.add("looprevil");	 	      		  	 	     	     	
            words.add("olos");	 	      		  	 	     	     	
            words.add("namrepus");	 	      		  	 	     	     	
            words.add("namredips");	 	      		  	 	     	     	
            words.add("etintrof");	 	      		  	 	     	     	
            words.add("321cba");	 	      		  	 	     	     	
            words.add("llabtoof");	 	      		  	 	     	     	
            words.add("nigol");	 	      		  	 	     	     	
            Collections.shuffle(words);	 	      		  	 	     	     	
            Random r = new Random();	 	      		  	 	     	     	
            return words.get(r.nextInt(words.size()));	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}