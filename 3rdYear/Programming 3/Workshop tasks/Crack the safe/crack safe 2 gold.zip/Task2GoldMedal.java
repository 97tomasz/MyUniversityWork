public class Task2GoldMedal	 	      		  	 	     	     	
{	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String unlockSafe(Safe safe, String[] words)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    System.out.println("here are the words to base passwords on:");	 	      		  	 	     	     	
    // add your safe unlocking code in here	 	      		  	 	     	     	
    for (String word: words)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      System.out.println(word);	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    System.out.println("But we'll try to unlock the safe with a different word:");	 	      		  	 	     	     	
    for (String word: words)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      String temp = "";	 	      		  	 	     	     	
      for (int i = word.length() -1;i>=0;i--)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
       temp += word.charAt(i);	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
      if (safe.unlock(temp))	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        System.out.println("Yes! we unlocked the safe.");	 	      		  	 	     	     	
        return safe.getSecretMessage();	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
      else	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        System.out.println("No! we tried " + word + ", but it didn't work.");	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
    return null;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}