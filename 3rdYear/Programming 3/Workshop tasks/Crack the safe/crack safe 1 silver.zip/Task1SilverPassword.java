import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.Arrays;	 	      		  	 	     	     	
import java.util.Collections;	 	      		  	 	     	     	
import java.util.List;	 	      		  	 	     	     	
import java.util.Random;	 	      		  	 	     	     	
	 	      		  	 	     	     	
/**	 	      		  	 	     	     	
 *	 	      		  	 	     	     	
 * @author ku14009	 	      		  	 	     	     	
 */	 	      		  	 	     	     	
public class Task1SilverPassword implements Password{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public String generatePassword() {	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
            // Sample Task1Silver Passwords based on List of 10 common English words for student code testing	 	      		  	 	     	     	
            words.add("Password");	 	      		  	 	     	     	
            words.add("Qwerty");	 	      		  	 	     	     	
            words.add("Manutd");	 	      		  	 	     	     	
            words.add("Chelsea");	 	      		  	 	     	     	
            words.add("Liverpool");	 	      		  	 	     	     	
            words.add("Solo");	 	      		  	 	     	     	
            words.add("Superman");	 	      		  	 	     	     	
            words.add("Spiderman");	 	      		  	 	     	     	
            words.add("Fortnite");	 	      		  	 	     	     	
            words.add("Abc123");	 	      		  	 	     	     	
            words.add("Football");	 	      		  	 	     	     	
            words.add("Login");	 	      		  	 	     	     	
             Collections.shuffle(words);	 	      		  	 	     	     	
            Random r = new Random();	 	      		  	 	     	     	
            return words.get(r.nextInt(words.size()));	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}