import java.util.List;	 	      		  	 	     	     	
import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.Collections;	 	      		  	 	     	     	
import java.util.Random;	 	      		  	 	     	     	
	 	      		  	 	     	     	
 // Do not modify this code it is to check your solution with a sample set of passwords suitable for the Task1Bronze Medal	 	      		  	 	     	     	
	 	      		  	 	     	     	
public class Task1BronzePassword implements Password{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public String generatePassword() {	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
            // Sample Task1Bronze Passwords based on List of 10 common English words for student code testing	 	      		  	 	     	     	
			words.add("password");	 	      		  	 	     	     	
            words.add("qwerty");	 	      		  	 	     	     	
            words.add("manutd");	 	      		  	 	     	     	
            words.add("chelsea");	 	      		  	 	     	     	
            words.add("liverpool");	 	      		  	 	     	     	
            words.add("solo");	 	      		  	 	     	     	
            words.add("superman");	 	      		  	 	     	     	
            words.add("spiderman");	 	      		  	 	     	     	
            words.add("fortnite");	 	      		  	 	     	     	
            words.add("abc123");	 	      		  	 	     	     	
            words.add("football");	 	      		  	 	     	     	
            words.add("login");	 	      		  	 	     	     	
	 	      		  	 	     	     	
			Collections.shuffle(words);	 	      		  	 	     	     	
            Random r = new Random();	 	      		  	 	     	     	
            return words.get(r.nextInt(words.size()));	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}