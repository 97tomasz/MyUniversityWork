import java.util.List;	 	      		  	 	     	     	
import java.util.ArrayList;	 	      		  	 	     	     	
	 	      		  	 	     	     	
 // Do not modify this code it is to check your solution with a sample Dictionary of words	 	      		  	 	     	     	
	 	      		  	 	     	     	
public class SampleWordsDictionary implements Dictionary{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public List<String> getListOfWords()	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
	 	      		  	 	     	     	
        // Sample List of 10 common English words in lower case for student code testing	 	      		  	 	     	     	
            words.add("password");	 	      		  	 	     	     	
            words.add("qwerty");	 	      		  	 	     	     	
            words.add("manutd");	 	      		  	 	     	     	
            words.add("chelsea");	 	      		  	 	     	     	
            words.add("liverpool");	 	      		  	 	     	     	
            words.add("solo");	 	      		  	 	     	     	
            words.add("superman");	 	      		  	 	     	     	
            words.add("spiderman");	 	      		  	 	     	     	
            words.add("fortnite");	 	      		  	 	     	     	
            words.add("abc123");	 	      		  	 	     	     	
            words.add("football");	 	      		  	 	     	     	
            words.add("login");	 	      		  	 	     	     	
	 	      		  	 	     	     	
            return words;	 	      		  	 	     	     	
	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
}