public class Task1GoldMedalMain {	 	      		  	 	     	     	
    public static void main(String args[]) {	 	      		  	 	     	     	
        // Do not modify this code	 	      		  	 	     	     	
        Dictionary sampleWords = new SampleWordsDictionary();	 	      		  	 	     	     	
        Password   samplePassword = new Task1GoldPassword();	 	      		  	 	     	     	
        Safe mySafe = new DummySafe(samplePassword.generatePassword(), "You have unlocked the dummy safe now test the real one!");	 	      		  	 	     	     	
        String result = new Task1GoldMedal().unlockSafe(mySafe, sampleWords.getListOfWords().stream().toArray(String[] ::new));	 	      		  	 	     	     	
       if (result != null)	 	      		  	 	     	     	
       {	 	      		  	 	     	     	
          System.out.println(result);	 	      		  	 	     	     	
       }	 	      		  	 	     	     	
       else	 	      		  	 	     	     	
       {	 	      		  	 	     	     	
          System.out.println("You have not unlocked the dummy safe. Modify your code before you try the real one.");	 	      		  	 	     	     	
       }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
}