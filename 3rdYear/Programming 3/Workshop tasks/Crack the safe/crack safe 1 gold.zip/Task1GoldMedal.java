public class Task1GoldMedal	 	      		  	 	     	     	
{	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String unlockSafe(Safe safe, String[] words)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
	 	      		  	 	     	     	
    System.out.println("here are the words to base passwords on:");	 	      		  	 	     	     	
    // add your safe unlocking code in here	 	      		  	 	     	     	
    for (String word: words)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      System.out.println(word);	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    for (String word: words)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      for (int i = 0; i < word.length(); i++)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        String temp = word.substring(i, i + 1).toUpperCase();	 	      		  	 	     	     	
        temp = word.substring(0,i) + temp + word.substring(i+1);	 	      		  	 	     	     	
        if (safe.unlock(temp))	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
          System.out.println("Yes! We unlocked the safe.");	 	      		  	 	     	     	
          return safe.getSecretMessage();	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
        else	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
          System.out.println("No! We tried " + temp + ", but it didn't work");	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
      return null;	 	      		  	 	     	     	
	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}