// Do not modify this code it is to check your solution with a dummy safe	 	      		  	 	     	     	
	 	      		  	 	     	     	
public interface Safe	 	      		  	 	     	     	
{	 	      		  	 	     	     	
   boolean unlock(String password);	 	      		  	 	     	     	
   String getSecretMessage();	 	      		  	 	     	     	
   boolean isUnlocked();	 	      		  	 	     	     	
}