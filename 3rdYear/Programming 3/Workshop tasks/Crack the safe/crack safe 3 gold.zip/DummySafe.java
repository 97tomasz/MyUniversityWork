// Do not modify this code it is to check your solution with a dummy safe	 	      		  	 	     	     	
	 	      		  	 	     	     	
public final class DummySafe implements Safe {	 	      		  	 	     	     	
	 	      		  	 	     	     	
    private final String password;	 	      		  	 	     	     	
    private final String secretMessage;	 	      		  	 	     	     	
    private boolean unlocked = false;	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
    public DummySafe(String password, String secretMessage) {	 	      		  	 	     	     	
        this.password = password;	 	      		  	 	     	     	
        this.secretMessage = secretMessage;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
    @Override	 	      		  	 	     	     	
    public boolean unlock(String password) {	 	      		  	 	     	     	
        if(this.password.equals(password)) {	 	      		  	 	     	     	
            unlocked = true;	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
        return isUnlocked();	 	      		  	 	     	     	
	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
    @Override	 	      		  	 	     	     	
    public String getSecretMessage() {	 	      		  	 	     	     	
       if(isUnlocked()) {	 	      		  	 	     	     	
           return secretMessage;	 	      		  	 	     	     	
       }	 	      		  	 	     	     	
       return null;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
	 	      		  	 	     	     	
    /**	 	      		  	 	     	     	
     * @return the unlocked	 	      		  	 	     	     	
     */	 	      		  	 	     	     	
    @Override	 	      		  	 	     	     	
    public boolean isUnlocked() {	 	      		  	 	     	     	
        return unlocked;	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
}