import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.Arrays;	 	      		  	 	     	     	
import java.util.Collections;	 	      		  	 	     	     	
import java.util.List;	 	      		  	 	     	     	
import java.util.Random;	 	      		  	 	     	     	
	 	      		  	 	     	     	
/**	 	      		  	 	     	     	
 *	 	      		  	 	     	     	
 * @author ku14009	 	      		  	 	     	     	
 */	 	      		  	 	     	     	
public class Task3GoldPassword implements Password{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public String generatePassword() {	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
            // Sample Task3Gold Passwords based on List of 10 common English words for student code testing	 	      		  	 	     	     	
            words.add("p4ssw0rd");	 	      		  	 	     	     	
            words.add("passw0rd");	 	      		  	 	     	     	
            words.add("ch3ls34");	 	      		  	 	     	     	
            words.add("ch3lse4");	 	      		  	 	     	     	
            words.add("l1v3rpool");	 	      		  	 	     	     	
            words.add("l1v3rp00l");	 	      		  	 	     	     	
            words.add("sup3rm4n");	 	      		  	 	     	     	
            words.add("sup3rman");	 	      		  	 	     	     	
            words.add("sp1derm4no");	 	      		  	 	     	     	
            words.add("spiderm4n0");	 	      		  	 	     	     	
            words.add("f0rtn1t3");	 	      		  	 	     	     	
            words.add("fortn1t3");	 	      		  	 	     	     	
            words.add("footb4ll");	 	      		  	 	     	     	
            words.add("f00tb4ll");	 	      		  	 	     	     	
            words.add("log1n");	 	      		  	 	     	     	
            words.add("l0g1n");	 	      		  	 	     	     	
            Collections.shuffle(words);	 	      		  	 	     	     	
            Random r = new Random();	 	      		  	 	     	     	
            return words.get(r.nextInt(words.size()));	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}