import java.util.List;	 	      		  	 	     	     	
import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.Collections;	 	      		  	 	     	     	
import java.util.Random;	 	      		  	 	     	     	
	 	      		  	 	     	     	
 // Do not modify this code it is to check your solution with a sample set of passwords suitable for the Task2Bronze Medal	 	      		  	 	     	     	
	 	      		  	 	     	     	
public class Task2BronzePassword implements Password{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public String generatePassword() {	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
            // Sample Task2Bronze Passwords based on List of 10 common English words for student code testing	 	      		  	 	     	     	
			 words.add("password12");	 	      		  	 	     	     	
            words.add("qwerty89");	 	      		  	 	     	     	
            words.add("manutd46");	 	      		  	 	     	     	
            words.add("chelsea81");	 	      		  	 	     	     	
            words.add("liverpool99");	 	      		  	 	     	     	
            words.add("solo21");	 	      		  	 	     	     	
            words.add("superman42");	 	      		  	 	     	     	
            words.add("spiderman88");	 	      		  	 	     	     	
            words.add("fortnite01");	 	      		  	 	     	     	
            words.add("abc12345");	 	      		  	 	     	     	
            words.add("football90");	 	      		  	 	     	     	
            words.add("login09");	 	      		  	 	     	     	
	 	      		  	 	     	     	
			Collections.shuffle(words);	 	      		  	 	     	     	
            Random r = new Random();	 	      		  	 	     	     	
            return words.get(r.nextInt(words.size()));	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}