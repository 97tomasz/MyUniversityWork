public class Task2BronzeMedalMain	 	      		  	 	     	     	
{	 	      		  	 	     	     	
    public static void main(String args[])	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
        // Do not modify this code it is to check your solution on a Dummy Safe with a sample Dictionary of words and passwords	 	      		  	 	     	     	
        Dictionary sampleWords = new SampleWordsDictionary();	 	      		  	 	     	     	
        Password   samplePassword = new Task2BronzePassword();	 	      		  	 	     	     	
        Safe mySafe = new DummySafe(samplePassword.generatePassword(), "Congratulations! You have unlocked the dummy safe now test the real one!");	 	      		  	 	     	     	
        String result = new Task2BronzeMedal().unlockSafe(mySafe, sampleWords.getListOfWords().stream().toArray(String[] ::new));	 	      		  	 	     	     	
       if (result != null)	 	      		  	 	     	     	
       {	 	      		  	 	     	     	
          System.out.println(result);	 	      		  	 	     	     	
       }	 	      		  	 	     	     	
       else	 	      		  	 	     	     	
       {	 	      		  	 	     	     	
          System.out.println("You have not unlocked the dummy safe. Modify your code before you try the real one.");	 	      		  	 	     	     	
       }	 	      		  	 	     	     	
	 	      		  	 	     	     	
	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
}