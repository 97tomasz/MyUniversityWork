import java.util.ArrayList;	 	      		  	 	     	     	
import java.util.Arrays;	 	      		  	 	     	     	
import java.util.Collections;	 	      		  	 	     	     	
import java.util.List;	 	      		  	 	     	     	
import java.util.Random;	 	      		  	 	     	     	
	 	      		  	 	     	     	
/**	 	      		  	 	     	     	
 *	 	      		  	 	     	     	
 * @author ku14009	 	      		  	 	     	     	
 */	 	      		  	 	     	     	
public class Task2SilverPassword implements Password{	 	      		  	 	     	     	
	 	      		  	 	     	     	
        @Override	 	      		  	 	     	     	
        public String generatePassword() {	 	      		  	 	     	     	
            List<String> words = new ArrayList<>();	 	      		  	 	     	     	
            // Sample Task2Silver Passwords based on List of 10 common English words for student code testing	 	      		  	 	     	     	
             words.add("Password45");	 	      		  	 	     	     	
            words.add("Qwerty23");	 	      		  	 	     	     	
            words.add("Manutd22");	 	      		  	 	     	     	
            words.add("Chelsea01");	 	      		  	 	     	     	
            words.add("Liverpool99");	 	      		  	 	     	     	
            words.add("Solo78");	 	      		  	 	     	     	
            words.add("Superman11");	 	      		  	 	     	     	
            words.add("Spiderman07");	 	      		  	 	     	     	
            words.add("Fortnite29");	 	      		  	 	     	     	
            words.add("Abc12321");	 	      		  	 	     	     	
            words.add("Football72");	 	      		  	 	     	     	
            words.add("Login38");	 	      		  	 	     	     	
             Collections.shuffle(words);	 	      		  	 	     	     	
            Random r = new Random();	 	      		  	 	     	     	
            return words.get(r.nextInt(words.size()));	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
	 	      		  	 	     	     	
}