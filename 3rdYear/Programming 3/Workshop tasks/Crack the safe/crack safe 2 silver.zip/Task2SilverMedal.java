public class Task2SilverMedal	 	      		  	 	     	     	
{	 	      		  	 	     	     	
	 	      		  	 	     	     	
  public String unlockSafe(Safe safe, String[] words)	 	      		  	 	     	     	
  {	 	      		  	 	     	     	
    for (String word: words)	 	      		  	 	     	     	
    {	 	      		  	 	     	     	
      for (int i = 0; i < 100; i++)	 	      		  	 	     	     	
      {	 	      		  	 	     	     	
        String temp2 = word;	 	      		  	 	     	     	
        String temp = "";	 	      		  	 	     	     	
        if (i < 10)	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
	 	      		  	 	     	     	
          word = word + "0" + Integer.toString(i);	 	      		  	 	     	     	
          temp = word.substring(0, 1).toUpperCase();	 	      		  	 	     	     	
          temp = temp + word.substring(1);	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
        else	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
          word = word + Integer.toString(i);	 	      		  	 	     	     	
          temp = word.substring(0, 1).toUpperCase();	 	      		  	 	     	     	
          temp = temp + word.substring(1);	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
        if (safe.unlock(temp))	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
          System.out.println("Yes! We unlocked the safe.");	 	      		  	 	     	     	
          return safe.getSecretMessage();	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
        else	 	      		  	 	     	     	
        {	 	      		  	 	     	     	
          System.out.println("No! We tried " + temp + ", but it didn't work");	 	      		  	 	     	     	
	 	      		  	 	     	     	
        }	 	      		  	 	     	     	
        word = temp2;	 	      		  	 	     	     	
      }	 	      		  	 	     	     	
    }	 	      		  	 	     	     	
    return null;	 	      		  	 	     	     	
  }	 	      		  	 	     	     	
}