﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class cert
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_1 = New System.Windows.Forms.Label()
        Me.lbl_DisplayName = New System.Windows.Forms.Label()
        Me.lbl_DisplayDOB = New System.Windows.Forms.Label()
        Me.lbl_DisplayIDNumber = New System.Windows.Forms.Label()
        Me.lbl_2 = New System.Windows.Forms.Label()
        Me.lbl_3 = New System.Windows.Forms.Label()
        Me.lbl_4 = New System.Windows.Forms.Label()
        Me.lbl_5 = New System.Windows.Forms.Label()
        Me.lbl_Unit1 = New System.Windows.Forms.Label()
        Me.lbl_Unit2 = New System.Windows.Forms.Label()
        Me.lbl_Unit3 = New System.Windows.Forms.Label()
        Me.lbl_6 = New System.Windows.Forms.Label()
        Me.lbl_DisplayOverall = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbl_1
        '
        Me.lbl_1.AutoSize = True
        Me.lbl_1.Font = New System.Drawing.Font("Modern No. 20", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_1.Location = New System.Drawing.Point(106, 9)
        Me.lbl_1.Name = "lbl_1"
        Me.lbl_1.Size = New System.Drawing.Size(462, 50)
        Me.lbl_1.TabIndex = 0
        Me.lbl_1.Text = "This is to Certify that"
        '
        'lbl_DisplayName
        '
        Me.lbl_DisplayName.AutoSize = True
        Me.lbl_DisplayName.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_DisplayName.Location = New System.Drawing.Point(252, 59)
        Me.lbl_DisplayName.Name = "lbl_DisplayName"
        Me.lbl_DisplayName.Size = New System.Drawing.Size(69, 24)
        Me.lbl_DisplayName.TabIndex = 1
        Me.lbl_DisplayName.Text = "Label1"
        '
        'lbl_DisplayDOB
        '
        Me.lbl_DisplayDOB.AutoSize = True
        Me.lbl_DisplayDOB.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_DisplayDOB.Location = New System.Drawing.Point(281, 83)
        Me.lbl_DisplayDOB.Name = "lbl_DisplayDOB"
        Me.lbl_DisplayDOB.Size = New System.Drawing.Size(69, 24)
        Me.lbl_DisplayDOB.TabIndex = 2
        Me.lbl_DisplayDOB.Text = "Label1"
        '
        'lbl_DisplayIDNumber
        '
        Me.lbl_DisplayIDNumber.AutoSize = True
        Me.lbl_DisplayIDNumber.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_DisplayIDNumber.Location = New System.Drawing.Point(290, 107)
        Me.lbl_DisplayIDNumber.Name = "lbl_DisplayIDNumber"
        Me.lbl_DisplayIDNumber.Size = New System.Drawing.Size(69, 24)
        Me.lbl_DisplayIDNumber.TabIndex = 3
        Me.lbl_DisplayIDNumber.Text = "Label1"
        '
        'lbl_2
        '
        Me.lbl_2.AutoSize = True
        Me.lbl_2.Font = New System.Drawing.Font("Modern No. 20", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_2.Location = New System.Drawing.Point(94, 131)
        Me.lbl_2.Name = "lbl_2"
        Me.lbl_2.Size = New System.Drawing.Size(499, 31)
        Me.lbl_2.TabIndex = 4
        Me.lbl_2.Text = "has achieved the following qualifications:"
        '
        'lbl_3
        '
        Me.lbl_3.AutoSize = True
        Me.lbl_3.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_3.Location = New System.Drawing.Point(97, 162)
        Me.lbl_3.Name = "lbl_3"
        Me.lbl_3.Size = New System.Drawing.Size(59, 18)
        Me.lbl_3.TabIndex = 5
        Me.lbl_3.Text = "Unit 1: "
        '
        'lbl_4
        '
        Me.lbl_4.AutoSize = True
        Me.lbl_4.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_4.Location = New System.Drawing.Point(97, 180)
        Me.lbl_4.Name = "lbl_4"
        Me.lbl_4.Size = New System.Drawing.Size(59, 18)
        Me.lbl_4.TabIndex = 6
        Me.lbl_4.Text = "Unit 2: "
        '
        'lbl_5
        '
        Me.lbl_5.AutoSize = True
        Me.lbl_5.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_5.Location = New System.Drawing.Point(97, 198)
        Me.lbl_5.Name = "lbl_5"
        Me.lbl_5.Size = New System.Drawing.Size(59, 18)
        Me.lbl_5.TabIndex = 7
        Me.lbl_5.Text = "Unit 3: "
        '
        'lbl_Unit1
        '
        Me.lbl_Unit1.AutoSize = True
        Me.lbl_Unit1.Location = New System.Drawing.Point(163, 166)
        Me.lbl_Unit1.Name = "lbl_Unit1"
        Me.lbl_Unit1.Size = New System.Drawing.Size(39, 13)
        Me.lbl_Unit1.TabIndex = 8
        Me.lbl_Unit1.Text = "Label1"
        '
        'lbl_Unit2
        '
        Me.lbl_Unit2.AutoSize = True
        Me.lbl_Unit2.Location = New System.Drawing.Point(162, 184)
        Me.lbl_Unit2.Name = "lbl_Unit2"
        Me.lbl_Unit2.Size = New System.Drawing.Size(39, 13)
        Me.lbl_Unit2.TabIndex = 9
        Me.lbl_Unit2.Text = "Label1"
        '
        'lbl_Unit3
        '
        Me.lbl_Unit3.AutoSize = True
        Me.lbl_Unit3.Location = New System.Drawing.Point(162, 202)
        Me.lbl_Unit3.Name = "lbl_Unit3"
        Me.lbl_Unit3.Size = New System.Drawing.Size(39, 13)
        Me.lbl_Unit3.TabIndex = 10
        Me.lbl_Unit3.Text = "Label1"
        '
        'lbl_6
        '
        Me.lbl_6.AutoSize = True
        Me.lbl_6.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_6.Location = New System.Drawing.Point(362, 168)
        Me.lbl_6.Name = "lbl_6"
        Me.lbl_6.Size = New System.Drawing.Size(126, 34)
        Me.lbl_6.TabIndex = 11
        Me.lbl_6.Text = "Overall: "
        '
        'lbl_DisplayOverall
        '
        Me.lbl_DisplayOverall.AutoSize = True
        Me.lbl_DisplayOverall.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_DisplayOverall.Location = New System.Drawing.Point(467, 168)
        Me.lbl_DisplayOverall.Name = "lbl_DisplayOverall"
        Me.lbl_DisplayOverall.Size = New System.Drawing.Size(126, 34)
        Me.lbl_DisplayOverall.TabIndex = 12
        Me.lbl_DisplayOverall.Text = "Overall: "
        '
        'cert
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 262)
        Me.Controls.Add(Me.lbl_DisplayOverall)
        Me.Controls.Add(Me.lbl_6)
        Me.Controls.Add(Me.lbl_Unit3)
        Me.Controls.Add(Me.lbl_Unit2)
        Me.Controls.Add(Me.lbl_Unit1)
        Me.Controls.Add(Me.lbl_5)
        Me.Controls.Add(Me.lbl_4)
        Me.Controls.Add(Me.lbl_3)
        Me.Controls.Add(Me.lbl_2)
        Me.Controls.Add(Me.lbl_DisplayIDNumber)
        Me.Controls.Add(Me.lbl_DisplayDOB)
        Me.Controls.Add(Me.lbl_DisplayName)
        Me.Controls.Add(Me.lbl_1)
        Me.Name = "cert"
        Me.Text = "cert"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl_1 As System.Windows.Forms.Label
    Friend WithEvents lbl_DisplayName As System.Windows.Forms.Label
    Friend WithEvents lbl_DisplayDOB As System.Windows.Forms.Label
    Friend WithEvents lbl_DisplayIDNumber As System.Windows.Forms.Label
    Friend WithEvents lbl_2 As System.Windows.Forms.Label
    Friend WithEvents lbl_3 As System.Windows.Forms.Label
    Friend WithEvents lbl_4 As System.Windows.Forms.Label
    Friend WithEvents lbl_5 As System.Windows.Forms.Label
    Friend WithEvents lbl_Unit1 As System.Windows.Forms.Label
    Friend WithEvents lbl_Unit2 As System.Windows.Forms.Label
    Friend WithEvents lbl_Unit3 As System.Windows.Forms.Label
    Friend WithEvents lbl_6 As System.Windows.Forms.Label
    Friend WithEvents lbl_DisplayOverall As System.Windows.Forms.Label
End Class
