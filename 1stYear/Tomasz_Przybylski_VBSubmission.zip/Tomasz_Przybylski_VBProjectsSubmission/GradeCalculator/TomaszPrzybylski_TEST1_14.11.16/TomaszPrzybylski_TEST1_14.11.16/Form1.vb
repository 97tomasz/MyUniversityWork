﻿Public Class frm_StudentDetails



    Private Sub frm_StudentDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Frm_Scores.Show()
    End Sub
End Class

