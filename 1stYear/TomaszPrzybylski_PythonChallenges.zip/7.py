name=input("what is your name? ")
age=int(input("How old are you currently? "))
nage = age + 1
print(name + ", next year you will be " +str(nage)+ " years old")
