import locale
locale.setlocale(locale.LC_ALL, '')
p=int(input("1 Pence:"))
p2=int(input("2 Pence:"))
p5=int(input("5 Pence:"))
p10=int(input("10 Pence:"))
p20=int(input("20 Pence:"))
p50=int(input("50 Pence:"))
pp1=int(input("1 Pound:"))
pp2=int(input("2 Pound:"))

total = int(p)*0.01 +int(p2)*0.02 +int(p5)*0.05 +int(p10)*0.1 +int(p20)*0.2 +int(p50)*0.5 +int(pp1)+int(pp2)*2
print(locale.currency(total,grouping=True))


