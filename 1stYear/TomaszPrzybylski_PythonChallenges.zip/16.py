import random
import time
rnd = random.randint(1,100)
correct = 0
count = 1
while correct != 1 :
    guess = input("Enter a guess... ")
    if int(guess) == rnd :
        print("Correct! You took " +str(count)+ " guesses!")
        correct = 1
    elif int(guess) != rnd :
        if int(guess) > rnd :
            print("Your guess was too high! Try again")
        elif int(guess) < rnd :
            print("Your guess was too low! Try again")
        count = count + 1
