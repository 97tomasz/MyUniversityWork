name=input("What is your name? ")
food=input("What is your favourite food? ")
print("Oh really " +name+ "? I can't say I am a fan of " +food " myself but thats cool")
