user = ""
user=input("What is your name? ")
ans1 = 0
ans2 = 0
ans3 = 0
ans4 = 0
ans5 = 0
count = 0
print("Welcome "+ user +" to this quiz")
print("Answer the following 4 questions")
print("Question #1")
print("What year was Shrek released?")
print("1. 2004")
print("2. 2001")
print("3. 2003")
print("4. 2002")
ans1 = input("Please enter your answer: ")
if ans1 == "2" :
    print("Well done! You got that one right!")
    count = count + 1
elif ans1 != "2" :
    print("Sorry, that's not correct")
print("Question #2")
print("Who voiced Lord Farquaad?")
print("1. John Lithgow")
print("2. Conrad Vernon")
print("3. Eddie Murphy")
print("4. Mike Myers")
ans2 = input("Please enter your answer: ")
if ans2 == "1" :
    print("Well done! You got that one right!")
    count =count + 1
elif ans2 != "1" :
    print("Sorry, that's not correct")
print("Question #3")
print("How much money has Shrek grossed at the worldwide box office?")
print("1. Almost $100 Million")
print("2. Almost $300 Million")
print("3. Almost $500 Million")
print("4. Almost $700 Million")
ans3 = input("Please enter your answer: ")
if ans3 == "3" :
    print("Well done! You got that one right!")
    count =count + 1
elif ans2 != "3" :
    print("Sorry, that's not correct")
print("Question #4")
print("Who directed the film?")
print("1. Michael Bay")
print("2. Steven Stielberg")
print("3. Mike Myers")
print("4. John Williams")
ans4 = input("Please enter your answer: ")
if ans4 == "4" :
    print("Well done! You got that one right!")
    count =count + 1
elif ans4 != "3" :
    print("Sorry, that's not correct")
print("Question #5. Last one!")
print("How many Shrek full feature films have been released as of 2017?")
print("1. 4")
print("2. 3")
print("3. 2")
print("4. 5")
ans5 = input("Please enter your answer: ")
if ans5 == "1" :
    print("Well done! You got that one right!")
    count =count + 1
elif ans5 != "1" :
    print("Sorry, that's not correct")

print("Out of 5 questions, you got " + str(count))
