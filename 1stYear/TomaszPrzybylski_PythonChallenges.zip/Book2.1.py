import random
first=input("Who is your first friend? ")
second=input("Who is your second friend? ")
rnd = random.randint(1,2)
if rnd == 1 :
    print("Friend 1: " + first + " is your best friend")
elif rnd == 2 :
    print("Friend 2: " + second + " is your best friend")
