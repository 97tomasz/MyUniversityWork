print ("Hello World")
print ("This is")
print ("a computer program")
print ("that prints on several lines")
