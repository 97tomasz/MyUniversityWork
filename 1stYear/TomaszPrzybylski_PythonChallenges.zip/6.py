daysperweek= 7
hoursperday= 24
minutesperhour= 60
minutesinaweek= daysperweek*hoursperday*minutesperhour
print("Minutes in a week = " +str(minutesinaweek))
