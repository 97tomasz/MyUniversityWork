fname=input("What is your first name? ")
sname=input("What is your surname? ")
print(fname + sname + " " + fname + sname + " " + fname + sname)
