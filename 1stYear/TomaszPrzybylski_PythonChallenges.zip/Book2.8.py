import random

choice = 1
while choice <> 2 :
    rnd = random.randint(1,6)
    print("What do you want to do?")
    print("1. Roll dice")
    print("2. Exit")
    choice = input()
    if choice == 1 :
        print("Dice Roll = " + str(rnd))
    elif choice == 2:
        print("Goodbye")
