password="changeme"
count = 0
while (count < 5):
    passin=input("Please enter password - ")
    if passin == password:
        print("Accepted")
        count = 6
    elif passin != password:
        count = count + 1
        print("Wrong password")
        print("You have had " +str(count)+ " attempts")
if (count == 5) :
    print("Account locked, please contact security to reset your password")
print("End")
