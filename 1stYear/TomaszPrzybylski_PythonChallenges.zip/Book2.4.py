import locale
locale.setlocale(locale.LC_ALL, '')
money=input("How much was spent? £")
if money > 10:
    print("20% discount")
    new= money*0.8
    print(locale.currency(new,grouping=True))
elif money <= 10:
    print("10% discount")
    new= money*0.9
    print(locale.currency(new,grouping=True))
