time=int(input("How long do you spend on the computer per day? "))
if time <=2 :
    print("You're alright, move along")
elif time<=4 :
    print("Do you have time for anything else?")
else :
    print("you need to get some fresh air once in a while, and a life")
