width=int(input("Please enter width: "))
height=int(input("Please enter height: "))
area= width * height
print(str(area))
