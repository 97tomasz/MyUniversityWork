
a=12
b=6
c=a+b
print(c)
