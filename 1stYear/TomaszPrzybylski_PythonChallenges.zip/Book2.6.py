import time
down = 10
while down <> 0 :
    print(down)
    down = down - 1
    time.sleep(1)
if down == 0 :
    print ("Blast off")
