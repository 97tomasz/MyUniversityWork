import random
import time
count = 0
while (count <= 9) :
    print(random.randint(0,100))
    time.sleep(3)
    count = count + 1
print("End")
