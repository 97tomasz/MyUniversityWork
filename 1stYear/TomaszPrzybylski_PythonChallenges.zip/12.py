import time
question=input("What is your question? ")
print("Let me think about that")
time.sleep(10)
print("I dont want to answer that question right now")
answer=input(question)
print("lol")
