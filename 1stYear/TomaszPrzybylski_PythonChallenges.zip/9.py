name=input("What is your name? ")
print("This is " + name + "'s first program")
