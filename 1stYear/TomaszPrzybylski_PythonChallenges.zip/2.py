word1="the"
word2="cat"
word3="sat"
word4="on"
word5="the"
word6="mat"
print (word1)
print (word2)
print (word3)
print (word4)
print (word5)
print (word6)
