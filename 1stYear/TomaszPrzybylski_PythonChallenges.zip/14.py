import time
for i in range (3, 0, -1):
    time.sleep(1)
    print(str(i))
time.sleep(1)
print("GO!")
